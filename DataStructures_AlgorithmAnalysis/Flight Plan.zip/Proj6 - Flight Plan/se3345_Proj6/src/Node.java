/*
Dijkstra's Flight Plan Algorithm with Priority Queue 
Node Class implementing Comparable by Zachary Tarell - 5/3/2019
This class compares nodes with time and cost of flights
 */

import java.util.*;

class Node implements Comparator<Node> {
    //Declare the required member varibles.
    public String node;
    public int time_to_cost;
    //Default constructor.
    public Node() {
        
    }
    //Define the parameteized constructor of the class.
    public Node(String n, int ct) {
        //Initialize the required member variables.
        this.node = n;
        this.time_to_cost = ct;
    }
    //Override the compare() method.
    @Override
    public int compare(Node n1, Node n2) {
        //If the cost time of node 1 is less the cost time of node 2, then return -1.
        if (n1.time_to_cost < n2.time_to_cost) {
            return -1;
        }
        //Otherwise, return 1.
        if (n1.time_to_cost > n2.time_to_cost) {
            return 1;
        }
        //If above two conditions are not satisfied then return 0.
        return 0;
    }
}

