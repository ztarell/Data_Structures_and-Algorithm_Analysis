/*
Dijkstra's Flight Plan Algorithm with Priority Queue 
Path Class by Zachary Tarell - 5/3/2019
This class checks of path exists between flights & delete and adds new nodes
 */

import java.util.*;

class Path {
    //Declare the required private member variables.
    private List<String> path_list;
    private String newnode;
    //Define the constructor of the class.
    public Path() {
        //Create an array list of the paths.
        path_list = new ArrayList<String>();
    }
    //Define the method setNewNode().
    public void setNewNode(String n) {
        this.newnode = n;
    }
    //Define the method getNewNode().
    public String getNewNode() {
        return this.newnode;
    }
    //Define the method exists().
    public Boolean pathExists(String a_node) {
        //If the current path_list contains the given node, then return true.
        if (path_list.contains(a_node)) {
            return true;
        }
            return false;
    }
    //Define the method add() to add a node to the path.
    public void addANode(String a_node) {
        //Add a node to the path list.
        path_list.add(a_node);
    }
    //Define the method delete() to delete a node from the path list.
    public void deleteANode(String a_node) {
        //Delete a node to the path list.
        path_list.remove(a_node);
    }
}