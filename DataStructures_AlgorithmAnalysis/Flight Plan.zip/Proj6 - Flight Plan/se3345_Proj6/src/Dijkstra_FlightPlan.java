/*
Dijkstra's Flight Plan Algorithm with Priority Queue 
Main Class by Zachary Tarell - 5/3/2019
This class reads 2 input files & writes an output file passed as arguments into command line
It throws FileNotFoundExceptions if files not found. 
It outputs the requested flight plan with time and cost weights
 */

import java.io.*;
import java.util.*;

public class Dijkstra_FlightPlan {

    //Declare the required private members variables.
    private HashMap<String, Integer> optDis;
    private HashMap<String, Integer> dist;
    private Set<String> setFlights;
    private List<Path> visit_list_nodes;
    private PriorityQueue<Node> queue;
    private int option_type, other;
    private String timeCost_of_path[][], src, dest;
    private List<String> list_of_nodes;

    //Define the constructor of the class.
    public Dijkstra_FlightPlan(List<String> list_of_nodes) {
        //Initialize the required member variales.
        this.list_of_nodes = list_of_nodes;
        optDis = new HashMap<String, Integer>();
        dist = new HashMap<String, Integer>();
        setFlights = new HashSet<String>();
        visit_list_nodes = new ArrayList<Path>();
        queue = new PriorityQueue<Node>(new Node());
    }

    //Define the method dijkstraAlgo().
    public void dijkstraAlgo(String timeCost_of_path[][], String path_request[]) {
        //Declare the required variables.
        String evaluate_node;
        src = path_request[0];
        dest = path_request[1];
        //If the item at the index 2 in the string array path_request is C.
        if (path_request[2].equalsIgnoreCase("C")) {
            //Take the option type as 2 and assign the value 3 to the variable other.
            option_type = 2;
            other = 3;
        } else {
            //Assign 3 to variable option_type.
            option_type = 3;
            //Assign 2 to the variable other.
            other = 2;
        }
        //Initialize the array timeCost_of_path.
        this.timeCost_of_path = timeCost_of_path;
        //Traverse the list of nodes.
        for (String item : list_of_nodes) {
            //Put the item retrieved from list of nodes in the hash map optDis.
            optDis.put(item, Integer.MAX_VALUE);
            //Put the item retrieved from list of nodes in the hash map dist.
            dist.put(item, Integer.MAX_VALUE);
        }
        //Add a new node at source into the priority queue.
        queue.add(new Node(src, 0));
        //Replace the item at (src, 0) in the hash map optDis.
        optDis.replace(src, 0);
        //Replace the item at (src, 0) in the hash map dist.
        dist.replace(src, 0);
        //Traverse the priority queue till it is empty.
        while (!queue.isEmpty()) {
            //Assign the returned value of the function findNodeOfMinDisFromPriorityQueue() to node evaluate_node.
            evaluate_node = findNodeOfMinDisFromPriorityQueue();
            //Create a new path of nodes.
            Path evaluated_list = new Path();
            //Set the node evaluated_node in the evaluated list.
            evaluated_list.setNewNode(evaluate_node);
            //Add the evaluated node to the set of settled flights.
            setFlights.add(evaluate_node);
            //Call the method evalNeighboursOfNode().
            evalNeighboursOfNode(evaluate_node, evaluated_list);
            //If the evaluated node exists in the list of visited nodes.
            if (!isNodeExists(visit_list_nodes, evaluate_node)) { //Add the list of evaluated nodes to the list of visited nodes.       
                visit_list_nodes.add(evaluated_list);
            }
        }
    }

    //Define the method isNodeExists().
    private boolean isNodeExists(List<Path> visit_list_nodes, String evaluate_node) {
        //Traverse the list of visited nodes.
        for (Path p : visit_list_nodes) {
            //If a node of the list of paths is equal to the evaluated node.
            if (p.getNewNode().equals(evaluate_node)) {
                return true;
            }
        }
        return false;
    }

    //Define the method findNodeOfMinDisFromPriorityQueue().
    private String findNodeOfMinDisFromPriorityQueue() {
        //Store the removed node from queue into a string node.
        String ret_node = queue.remove().node;
        //Return the retrieved node.
        return ret_node;
    }

    //Define the method evalNeighboursOfNode().
    private void evalNeighboursOfNode(String evaluate_node, Path evaluated_list) {
        //Declare and initialize the required variables.
        int dist_edge = -1;
        int newDist = -1;
        //Traverse the array timeCost_of_path[][].
        for (int i = 0; i < timeCost_of_path.length; i++) {
            //If the current element of the first column is equal to the evaluated node.
            if (!timeCost_of_path[i][0].equals(evaluate_node)) {
                continue;
            }
            //Declare a variable to store a destination node.
            String destNode;
            //Traverse the list of nodes.
            for (int j = 0; j < list_of_nodes.size(); j++) {
                //Store the current value of list of nodes into a variable destNode.
                destNode = list_of_nodes.get(j);
                //If the current element of the second column is equal to the destNode.
                if (!timeCost_of_path[i][1].equals(destNode)) {
                    continue;
                }
                //If the list of settled flights does not contain the destNode.
                if (!setFlights.contains(destNode)) {
                    //Get the distance of an edge.
                    dist_edge = Integer.parseInt(timeCost_of_path[i][option_type]);
                    //Get the new distance
                    newDist = optDis.get(evaluate_node) + dist_edge;
                    //If the new distance is less than the optimal distance of destination node.
                    if (newDist < optDis.get(destNode)) {
                        //Replace the new distance with the destination node in the hash map optDis.
                        optDis.replace(destNode, newDist);
                        //Replace the node at the distance of evaluated node plus time of cost of a path with the destination node in the hash map dist.
                        dist.replace(destNode, dist.get(evaluate_node) + Integer.parseInt(timeCost_of_path[i][other]));
                        //Traverse the list of visited nodes.
                        for (Path p : visit_list_nodes) {
                            //If the path from the destination node exists. 
                            if (p.pathExists(destNode)) { //Delete the destination node from the list of paths.
                                p.deleteANode(destNode);
                            }
                            //Break the loop.
                            break;
                        }
                        //Add the destination node to the list of evaluated nodes.
                        evaluated_list.addANode(destNode);
                    }
                    //Add a new node to the priority queue.
                    queue.add(new Node(destNode, optDis.get(destNode)));
                }
            }
        }
    }

    //Start the execution of the main() method.
    public static void main(String[] args) throws FileNotFoundException {
                  
        //Here are the three argument strings inserted from command line
        args[0] = "FlightData.txt";
        args[1] = "RequestedFlightData.txt";
        args[2] = "output.txt";
              
        //Declare the required variables.
        String timeCost_of_path[][], list_of_requested_paths[][];
        BufferedReader data_of_flight, requested_data_of_flight;
        List<String> list_nodes;
        //Open the output file with the help of PrintWriter.
        PrintWriter outfile = new PrintWriter(args[2]);
        try {
            //Read the data from the input file "FlightData.txt".
            data_of_flight = new BufferedReader(new FileReader(args[0]));
            //Read the data from the input file "RequestedFlightData.txt".
            requested_data_of_flight = new BufferedReader(new FileReader(args[1]));
            //Declare a string variable to store a line of a file.
            String line;
            //Create an array list of nodes.
            list_nodes = new ArrayList<String>();
            //Create a string array to store the time of cost of a path.
            timeCost_of_path = new String [Integer.parseInt(data_of_flight.readLine())][4];
            //Create a string array to store the list of requested paths.
            list_of_requested_paths = new String [Integer.parseInt(requested_data_of_flight.readLine())][3];
            //Declare the required variables.
            int i = 0, j;
            String nnode;
            //Read the lines from the input file till there are no line to read.
            while ((line = data_of_flight.readLine()) != null) {
                j = 0;
                //Tokenize the line read using the delimeter '|'.
                StringTokenizer str_data = new StringTokenizer(line, "|");
                int k = 1;
                //Start the while loop till the value of k becomes less than or equal to 2.
                while (k <= 2) {
                    //If the node list does not contain the node which contains the next token from the tokenize string str_data.
                    if (!list_nodes.contains(nnode = str_data.nextToken())) {
                        //Get the node to the array timeCost_of_path[][] at (i, j++).
                        timeCost_of_path[i][j++] = nnode;
                        //Add the nnode to the list_nodes.
                        list_nodes.add(nnode);
                    } else {//Store the node to the array timeCost_of_path[][] at (i, j++).
                        timeCost_of_path[i][j++] = nnode;
                    }
                    //Increment the value of the k.
                    k++;
                }
                //Start the while loop till the tokenize string str_data has more tokens.
                while (str_data.hasMoreTokens()) {
                    //Store the next token of the tokenize string into the array timecost_of_oath at (i, j++).
                    timeCost_of_path[i][j++] = str_data.nextToken();
                }
                //Increment the value of i.
                i++;
            }
            //Initialize the value of i to 0.
            i = 0;
            //Read the second input file line by line.
            while ((line = requested_data_of_flight.readLine()) != null) {
                j = 0;
                //Tokenize the line read by the delimeter '|'.
                StringTokenizer tok_data = new StringTokenizer(line, "|");
                //Start the while loop till the tokenize string has more tokens.
                while (tok_data.hasMoreTokens()) {
                    //Store the next token to the array list_of_requested_paths[][] at (i, j++).              
                    list_of_requested_paths[i][j++] = tok_data.nextToken();
                }
                //Increment the value of i.
                i++;
            }
            //Initialize the value of i to 1.
            i = 1;
            //traverse the array list_of_requested_paths[][].
            for (String req_path[] : list_of_requested_paths) {
                //If the list of nodes does not contain the required item.
                if (!(list_nodes.contains(req_path[0]) && list_nodes.contains(req_path[1]))) {
                    //Write the following sting to the output file.
                    outfile.println("NO FLIGHT AVAILABLE FOR THE REQUEST");
                    //Continue the loop.
                    continue;
                }
                //Create an object of the class to call the constructor.
                Dijkstra_FlightPlan dijPrQ = new Dijkstra_FlightPlan(list_nodes);
                //Call the method dijkstraAlgo() method to run the Dijkstra's algorithm
                dijPrQ.dijkstraAlgo(timeCost_of_path, req_path);
                //Traverse the node's list.
                for (String node : list_nodes) {
                    //If the node is equal to the destination node of the class.
                    if (!node.equals(dijPrQ.dest)) {
                        continue;
                    }
                    //Create a list of complete paths.
                    List<String> comp_path = getPath(dijPrQ.visit_list_nodes, dijPrQ.dest);
                    outfile.print(comp_path.size() - 1 + "|");
                    //Traverse the list of complete paths.
                    for (int k = 0; k < comp_path.size(); k++) {
                        //If the k is equal to last index of the list of complete paths.
                        if (k == comp_path.size() - 1) {//Display the element at the index k of this list.
                            outfile.print(comp_path.get(k) + "|");
                        } else {//Otherwise, display the element at the index k of this list.                        
                            outfile.print(comp_path.get(k) + "|");
                        }
                    }
                    //Display the typeand its values to the output file.
                    outfile.println(dijPrQ.optDis.get(node) + "|" + dijPrQ.dist.get(node));//Cost|Time
                    break;
                }
                i++;
            }
        } //Define the catch block in case of an exception.
        catch (Exception e) {
            System.out.println("Exception:" + e.toString());
        }
        //Close the output file.
        outfile.close();
    }

    //Define the method getPath() to find a complete path.
    private static List<String> getPath(List<Path> visit_list_nodes, String dest) {
        //Create another list of complete paths.
        List<String> comp_path = new ArrayList<String>();
        //Traverse the list of visited nodes.
        for (Path p : visit_list_nodes) {
            //If the required destination node does not exist in the path.
            if (!p.pathExists(dest)) {
                continue;
            }
            //recursively call the function getPath() to find a complete path.
            comp_path = getPath(visit_list_nodes, p.getNewNode());
            //Add the destination node to the complete path.
            comp_path.add(dest);
            //return the complete path list.
            return comp_path;
        }
        comp_path.add(dest);
        return comp_path;
    }
}