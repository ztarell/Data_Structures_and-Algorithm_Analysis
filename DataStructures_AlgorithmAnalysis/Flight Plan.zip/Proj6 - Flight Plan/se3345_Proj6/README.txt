******** NetBeans IDE 8.2 ************

By: Zachary Tarell
zjt170000
SE-3345.003
Spring 2019

Project 6 - Flight Plan using Dijkstra's Shortest Path Algorithm

This project uses NetBeans IDE,  and passes three arguments. A data file named "FlightData.txt", and a query file named "RequestedFlightData.txt" and creates an output file named "output.txt" (samples below). It has a main class that's named "Dijkstra_FlightPlan", and supporting class named "Path", and a class that implements Comparable named "Node".

The program, it determines the shortest/cheapest flight plans for a person wishing to travel between two different cities serviced by an airline (assuming a path exists), using Dijkstra�s algorithm with priority queues. The first 2 arguments passed as .txt files start with the size of the array followed by the data the information (examples below). The output file writes num of legs|source(s) to destination|cost|time.

	"FlightData.txt"
7
Dallas|Austin|98|47
Austin|Houston|95|39
Dallas|Houston|101|51
Austin|Chicago|144|192
Chicago|Austin|155|200
Austin|Dallas|100|50
Houston|Dallas|100|50

	"RequestedFlightData.txt"
4
Dallas|Houston|T
Chicago|Dallas|C
Houston|Austin|C
NewYork JFK|Dallas|C


Sample Run:

javac Dijkstra_FlightPlan.java

java Dijkstra_FlightPlan FlightData.txt RequestedFlightData.txt output.txt

	"output.txt"
1|Dallas|Houston|51|101
2|Chicago|Austin|Dallas|255|250
2|Houston|Dallas|Austin|198|97
NO FLIGHT AVAILABLE FOR THE REQUEST 