/*
 * IDedObject Interface
 * By Zachary Tarell
 * Class: SE-3345
 * Section: 003
 * Semester: Spring 2019
 * 2/14/19
 */
public interface IDedObject {

    int getID();

    void printID();

    int compareTo(int x);

}
