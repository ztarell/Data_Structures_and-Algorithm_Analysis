******** NetBeans IDE 8.2 ************

By: Zachary Tarell
zjt170000
SE-3345.003
Spring 2019

Project 4 - Red Black Tree

This project uses NetBeans IDE,  and passes two arguments. An input file named "Input.txt" and creates an output file named "output.txt" (samples below). It has a main class is named "RBT_Main_Tarell" and supporting class named "RedBlackTree".

Sample Run:

"Input.txt"

Integer
Insert:98
Insert:-68
Insert:55
Insert:45
PrintTree
Contains:45
Insert:84
Insert:32
Insert:132
Insert:45
PrintTree
Insert
hih

"output.txt"

True
True
True
True
*55 -68 *45 *98 
True
True
True
True
False
84 55 *32 *-68 45 98 *132 
Error in Line: Insert
Error in Line: hih