
NetBeans IDE 8.2



By: Zachary Tarell

zjt170000
SE-3345.003

Spring 2019


Project 2 - Magazine and SinglyLinkedList



run:

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 3
Enter Magazine ID: 
123
Enter Magazine Name: 
People
Enter Publisher Name: 
People

Magazine Added!

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 3
Enter Magazine ID: 
456
Enter Magazine Name: 
Weekly
Enter Publisher Name: 
Weekly

Magazine Added!

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 6

	456
	Weekly
	Weekly

	123
	People
	People

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 5
Enter ID: 
456
Item with id 456 deleted

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 6

	123
	People
	People

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 2
Enter ID: 
123

	123
	People
	People

------- Magazine Operations ---------
1. Make Empty
2. Find ID
3. Insert At Front
4. Delete From Front
5. Delete ID
6. Print All Records
7. Exit
  Your Choice: 7
BUILD SUCCESSFUL (total time: 1 minute 11 seconds)